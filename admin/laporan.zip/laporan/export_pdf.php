<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

$pdo = getConnection();

$type       = $_GET['type'] ?? 'stok';
$start_date = $_GET['start_date'] ?? '';
$end_date   = $_GET['end_date'] ?? '';
$kategori_id= $_GET['kategori_id'] ?? '';
$lokasi_id  = $_GET['lokasi_id'] ?? '';
$status     = $_GET['status'] ?? '';

// HTML awal
$html = '<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Laporan</title>
<style>
body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
table { width: 100%; border-collapse: collapse; margin-top: 10px; }
th, td { border: 1px solid #000; padding: 6px; text-align: left; }
th { background: #f0f0f0; }
h2 { margin-bottom: 0; }
</style>
</head>
<body>';

$html .= '<h2>Laporan ' . htmlspecialchars(ucfirst($type)) . '</h2>';
if (!empty($start_date) || !empty($end_date)) {
    $html .= '<p>Periode: ' . htmlspecialchars($start_date ?: '-') . ' s/d ' . htmlspecialchars($end_date ?: '-') . '</p>';
}

if ($type === 'stok') {
    $sql = "SELECT kode_barang, nama_barang, nama_kategori, nama_lokasi, jumlah_total, jumlah_tersedia,
                   (jumlah_total - jumlah_tersedia) AS jumlah_dipinjam, kondisi, tahun_pengadaan, harga_perolehan
            FROM v_stok_barang
            WHERE 1=1";
    $params = [];

    if (!empty($kategori_id)) {
        $sql .= " AND id IN (SELECT b.id FROM barang b WHERE b.kategori_id = :kategori_id)";
        $params[':kategori_id'] = $kategori_id;
    }
    if (!empty($lokasi_id)) {
        $sql .= " AND id IN (SELECT b.id FROM barang b WHERE b.lokasi_id = :lokasi_id)";
        $params[':lokasi_id'] = $lokasi_id;
    }
    if (!empty($status)) {
        $sql .= " AND kondisi = :status";
        $params[':status'] = $status;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    $html .= '<table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Nama</th>
                <th>Kategori</th>
                <th>Lokasi</th>
                <th>Total</th>
                <th>Tersedia</th>
                <th>Dipinjam</th>
                <th>Kondisi</th>
                <th>Tahun</th>
                <th>Harga</th>
            </tr>
        </thead>
        <tbody>';
    $no = 1;
    foreach ($rows as $r) {
        $html .= "<tr>
            <td>{$no}</td>
            <td>{$r['kode_barang']}</td>
            <td>{$r['nama_barang']}</td>
            <td>{$r['nama_kategori']}</td>
            <td>{$r['nama_lokasi']}</td>
            <td>{$r['jumlah_total']}</td>
            <td>{$r['jumlah_tersedia']}</td>
            <td>{$r['jumlah_dipinjam']}</td>
            <td>{$r['kondisi']}</td>
            <td>{$r['tahun_pengadaan']}</td>
            <td>{$r['harga_perolehan']}</td>
        </tr>";
        $no++;
    }
    $html .= '</tbody></table>';

} elseif ($type === 'peminjaman') {
    $sql = "SELECT p.kode_peminjaman, b.nama_barang, p.peminjam_nama, p.jumlah_pinjam, p.tanggal_pinjam,
                   p.tanggal_kembali_rencana, p.tanggal_kembali_aktual, p.status, u.nama_lengkap AS petugas
            FROM peminjaman p
            JOIN barang b ON p.barang_id = b.id
            JOIN users u ON p.created_by = u.id
            WHERE 1=1";
    $params = [];
    if (!empty($start_date) && !empty($end_date)) {
        $sql .= " AND p.tanggal_pinjam BETWEEN :start AND :end";
        $params[':start'] = $start_date;
        $params[':end'] = $end_date;
    }
    if (!empty($status)) {
        $sql .= " AND p.status = :status";
        $params[':status'] = $status;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    $html .= '<table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Barang</th>
                <th>Peminjam</th>
                <th>Jumlah</th>
                <th>Tgl Pinjam</th>
                <th>Jatuh Tempo</th>
                <th>Kembali</th>
                <th>Status</th>
                <th>Petugas</th>
            </tr>
        </thead>
        <tbody>';
    $no = 1;
    foreach ($rows as $r) {
        $html .= "<tr>
            <td>{$no}</td>
            <td>{$r['kode_peminjaman']}</td>
            <td>{$r['nama_barang']}</td>
            <td>{$r['peminjam_nama']}</td>
            <td>{$r['jumlah_pinjam']}</td>
            <td>{$r['tanggal_pinjam']}</td>
            <td>{$r['tanggal_kembali_rencana']}</td>
            <td>{$r['tanggal_kembali_aktual']}</td>
            <td>{$r['status']}</td>
            <td>{$r['petugas']}</td>
        </tr>";
        $no++;
    }
    $html .= '</tbody></table>';

} elseif ($type === 'terlambat') {
    $sql = "SELECT kode_peminjaman, nama_barang, peminjam_nama, tanggal_pinjam,
                   tanggal_kembali_rencana,
                   DATEDIFF(CURDATE(), tanggal_kembali_rencana) AS hari_terlambat,
                   status
            FROM v_laporan_peminjaman
            WHERE status='dipinjam' AND tanggal_kembali_rencana < CURDATE()";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $rows = $stmt->fetchAll();

    $html .= '<table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Barang</th>
                <th>Peminjam</th>
                <th>Tgl Pinjam</th>
                <th>Jatuh Tempo</th>
                <th>Keterlambatan</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>';
    $no = 1;
    foreach ($rows as $r) {
        $html .= "<tr>
            <td>{$no}</td>
            <td>{$r['kode_peminjaman']}</td>
            <td>{$r['nama_barang']}</td>
            <td>{$r['peminjam_nama']}</td>
            <td>{$r['tanggal_pinjam']}</td>
            <td>{$r['tanggal_kembali_rencana']}</td>
            <td>{$r['hari_terlambat']} hari</td>
            <td>{$r['status']}</td>
        </tr>";
        $no++;
    }
    $html .= '</tbody></table>';

} elseif ($type === 'user') {
    $sql = "SELECT username, nama_lengkap, role, status, created_at FROM users";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $rows = $stmt->fetchAll();

    $html .= '<table>
        <thead>
            <tr>
                <th>No</th>
                <th>Username</th>
                <th>Nama</th>
                <th>Role</th>
                <th>Status</th>
                <th>Tgl Buat</th>
            </tr>
        </thead>
        <tbody>';
    $no = 1;
    foreach ($rows as $r) {
        $html .= "<tr>
            <td>{$no}</td>
            <td>{$r['username']}</td>
            <td>{$r['nama_lengkap']}</td>
            <td>{$r['role']}</td>
            <td>{$r['status']}</td>
            <td>{$r['created_at']}</td>
        </tr>";
        $no++;
    }
    $html .= '</tbody></table>';
} else {
    $html .= "<p>Tipe laporan tidak dikenali.</p>";
}

$html .= "</body></html>";

// Generate PDF
$options = new Options();
$options->set('isRemoteEnabled', true);

$pdf = new Dompdf($options);
$pdf->loadHtml($html);
$pdf->setPaper('A4', 'landscape');
$pdf->render();

$filename = "Laporan_{$type}_" . date('YmdHis') . ".pdf";
$pdf->stream($filename, ["Attachment" => true]);
exit;
